import halftone
h = halftone.Halftone('jc.jpg')
h.make(style='grayscale', sample=6)
