criei um ambiente virtual chamado halftoning (n�o necessario)

nele instalei o Pillow (pip install Pillow)

botei nele os arquivos halftone.py, trial.py e jc.jpg

python trial.py roda e cria o arquivo jc_halftoned.jpg


PROCEDIMENTO NA IMAGEM ANEXA
